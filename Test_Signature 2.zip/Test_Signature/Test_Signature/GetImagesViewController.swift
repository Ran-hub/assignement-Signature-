//
//  GetImagesViewController.swift
//  Test_Signature
//
//  Created by Ranjith on 02/01/2019.
//  Copyright © 2019 AMT_INDIA. All rights reserved.
//

import Foundation
import UIKit

class GetImagesViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
let imagePicker = UIImagePickerController()
var focus: UIImageView!

    
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

 }
    @IBAction func selectSignature1(_ sender: AnyObject) {
       // openPhotoLibraryForSelectSignature()
        focus = imageView1
        openPhotoLibraryForSelectSignature()


    }
    @IBAction func selectPhoto(_sender: AnyObject){
      //  openPhotoLibraryForSelectPhoto()
        
        focus = imageView2
        openPhotoLibraryForSelectPhoto()
        

    }
//
    func openPhotoLibraryForSelectSignature() {

        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
            print("can't open photo library")
            return
        }

        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self

        present(imagePicker, animated: true)
    }
//
    func openPhotoLibraryForSelectPhoto() {
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
            print("can't open photo library")
            return
        }

        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self

        present(imagePicker, animated: true)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        let image = info [UIImagePickerController.InfoKey.originalImage] as? UIImage
//
//
//        self.dismiss(animated: true, completion: nil)
//        imageView1.image = image
//
//    }
    

//    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info [UIImagePickerController.InfoKey.originalImage] as? UIImage

        self.dismiss(animated: true, completion: nil)
        focus.image = image
    }

    
}


    

    

