//
//  SignatureViewDelegate.swift
//  Test_Signature
//
//  Created by Ranjith on 17/12/2018.
//  Copyright © 2018 AMT_INDIA. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate, UIPickerViewDelegate, UINavigationControllerDelegate, YPSignatureDelegate {
    
    
    @IBOutlet weak var signatureView: YPDrawSignatureView!
    var imagePicker: UIImagePickerController!
    
    enum ImageSource {
        case photoLibrary
        case camera
    }
    override func viewDidLoad() {
        super.viewDidLoad()
       
        signatureView.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
   
    @IBAction func clearSignature(_ sender: UIButton) {
        
        self.signatureView.clear()
    }
    

    @IBAction func saveSignature(_ sender: UIButton) {
      
        if let signatureImage = self.signatureView.getSignature(scale: 10) {
            
        
            UIImageWriteToSavedPhotosAlbum(signatureImage, nil, nil, nil)
            
            
           self.signatureView.clear()
        }
    }

    
    func didStart(_ view : YPDrawSignatureView) {
        print("Started Drawing")
    }
 
    func didFinish(_ view : YPDrawSignatureView) {
        print("Finished Drawing")
    }
    

}



